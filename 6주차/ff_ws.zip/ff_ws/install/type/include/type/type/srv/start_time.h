// generated from rosidl_generator_c/resource/idl.h.em
// with input from type:srv/StartTime.idl
// generated code does not contain a copyright notice

#ifndef TYPE__SRV__START_TIME_H_
#define TYPE__SRV__START_TIME_H_

#include "type/srv/detail/start_time__struct.h"
#include "type/srv/detail/start_time__functions.h"
#include "type/srv/detail/start_time__type_support.h"

#endif  // TYPE__SRV__START_TIME_H_
